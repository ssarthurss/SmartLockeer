allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// CORREÇÃO: plugins antigos (como o nfc_manager) compilam contra o Android 31.
// Isto força todos os plugins a compilarem com o Android 36.
// Precisa vir ANTES do bloco "evaluationDependsOn" abaixo.
subprojects {
    afterEvaluate {
        val android = extensions.findByName("android")
        if (android is com.android.build.gradle.BaseExtension) {
            android.compileSdkVersion(36)
        }
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
